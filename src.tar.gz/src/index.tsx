import { Hono } from 'hono'
import { html } from 'hono/html'

const app = new Hono()

/**
 * Jordan Inspiration Tours - Single Page Website
 * ------------------------------------------------
 * All markup, styles and behaviour are shipped as a single HTML document.
 * - Tailwind CSS via CDN for utility styling (rapid prototyping / responsive)
 * - FontAwesome for icons
 * - Vanilla JS for language switching, booking modal, and interactive UI
 * - Translations live in a single JS dictionary (see /static/app.js -> TRANSLATIONS)
 *   so it's easy to edit copy or add languages later.
 */
app.get('/', (c) => {
  return c.html(html`<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Jordan Inspiration Tours - Discover Petra, one of the Seven Wonders of the World, with our expert guides and curated tour packages." />
  <title data-i18n="meta.title">Jordan Inspiration Tours - Petra Experiences</title>
  <link rel="icon" type="image/svg+xml" href="/static/favicon.svg" />

  <!-- Tailwind CSS (CDN) -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- FontAwesome Icons -->
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet" />

  <!-- Google Fonts: Playfair (headings) + Inter (body EN) + Cairo (body AR) -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Inter:wght@400;500;600;700&family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet" />

  <!-- Custom styles + Tailwind color palette configuration -->
  <link href="/static/style.css" rel="stylesheet" />
  <script>
    // Extend Tailwind's default palette with Petra-inspired colors.
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            // Rose-red tones of the Siq / Petra sandstone
            petra: {
              50:  '#fdf5f3',
              100: '#fbe8e2',
              200: '#f6c8bb',
              300: '#eea08a',
              400: '#e07156',
              500: '#c94a2c',   // primary rose-red
              600: '#a63820',
              700: '#82291a',   // deep siq
              800: '#5a1c13',
              900: '#3a120c',
            },
            // Desert gold / sand tones
            sand: {
              50:  '#fdfaf3',
              100: '#f8efd8',
              200: '#f0dda8',
              300: '#e5c374',
              400: '#d9a94a',
              500: '#c99236',   // desert gold
              600: '#a5732a',
              700: '#7f5722',
              800: '#5d3f1c',
              900: '#3d2913',
            }
          },
          fontFamily: {
            display: ['"Playfair Display"', 'serif'],
            body:    ['Inter', 'system-ui', 'sans-serif'],
            arabic:  ['Cairo', 'system-ui', 'sans-serif'],
          }
        }
      }
    }
  </script>
</head>

<body class="font-body bg-sand-50 text-petra-900 antialiased">

  <!-- =========================================================
       NAVBAR
       ========================================================= -->
  <header id="navbar" class="fixed top-0 inset-x-0 z-50 transition-all duration-300 bg-white/80 backdrop-blur-md border-b border-sand-200">
    <nav class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">

      <!-- Brand / Logo -->
      <a href="#home" class="flex items-center gap-3 shrink-0">
        <!-- Logo Here -->
        <div class="w-10 h-10 rounded-full bg-gradient-to-br from-petra-500 to-sand-500 flex items-center justify-center text-white shadow-md">
          <i class="fa-solid fa-mountain-sun text-lg"></i>
        </div>
        <div class="leading-tight">
          <div class="font-display font-bold text-lg text-petra-700" data-i18n="brand.name">Jordan Inspiration Tours</div>
          <div class="text-[11px] uppercase tracking-widest text-sand-600" data-i18n="brand.tagline">Petra & Beyond</div>
        </div>
      </a>

      <!-- Desktop nav links -->
      <ul class="hidden lg:flex items-center gap-8 text-sm font-medium">
        <li><a href="#home"         class="hover:text-petra-500 transition" data-i18n="nav.home">Home</a></li>
        <li><a href="#packages"     class="hover:text-petra-500 transition" data-i18n="nav.packages">Packages</a></li>
        <li><a href="#guides"       class="hover:text-petra-500 transition" data-i18n="nav.guides">Guides</a></li>
        <li><a href="#testimonials" class="hover:text-petra-500 transition" data-i18n="nav.testimonials">Testimonials</a></li>
        <li><a href="#contact"      class="hover:text-petra-500 transition" data-i18n="nav.contact">Contact</a></li>
      </ul>

      <!-- Right side actions -->
      <div class="flex items-center gap-2 sm:gap-3">
        <!-- Language switcher -->
        <button id="lang-switcher"
                class="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-full border border-petra-300 text-petra-700 hover:bg-petra-500 hover:text-white hover:border-petra-500 transition text-sm font-semibold">
          <i class="fa-solid fa-globe"></i>
          <span id="lang-switcher-label">العربية</span>
        </button>

        <!-- Book CTA (hidden on very small screens to save space) -->
        <a href="#packages"
           class="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-petra-500 text-white hover:bg-petra-600 shadow-md transition text-sm font-semibold">
          <i class="fa-solid fa-calendar-check"></i>
          <span data-i18n="nav.book">Book Now</span>
        </a>

        <!-- Mobile menu toggle -->
        <button id="mobile-menu-btn"
                class="lg:hidden w-10 h-10 flex items-center justify-center rounded-lg text-petra-700 hover:bg-sand-100">
          <i class="fa-solid fa-bars text-xl"></i>
        </button>
      </div>
    </nav>

    <!-- Mobile menu drawer -->
    <div id="mobile-menu" class="lg:hidden hidden border-t border-sand-200 bg-white">
      <ul class="flex flex-col p-4 gap-3 text-base font-medium">
        <li><a href="#home"         class="block py-2 hover:text-petra-500" data-i18n="nav.home">Home</a></li>
        <li><a href="#packages"     class="block py-2 hover:text-petra-500" data-i18n="nav.packages">Packages</a></li>
        <li><a href="#guides"       class="block py-2 hover:text-petra-500" data-i18n="nav.guides">Guides</a></li>
        <li><a href="#testimonials" class="block py-2 hover:text-petra-500" data-i18n="nav.testimonials">Testimonials</a></li>
        <li><a href="#contact"      class="block py-2 hover:text-petra-500" data-i18n="nav.contact">Contact</a></li>
      </ul>
    </div>
  </header>

  <!-- =========================================================
       HERO
       ========================================================= -->
  <section id="home" class="relative min-h-screen flex items-center justify-center overflow-hidden">
    <!-- Background image: Al-Khazneh (The Treasury) at Petra -->
    <div class="absolute inset-0 bg-cover bg-center scale-105"
         style="background-image: url('https://sspark.genspark.ai/cfimages?u1=3IyqlmQrCtUKHE9F6HvemODPq4OUqn6cHvhJtW5epMr8gw5jRncqVtTpC2u0wnRpuFabN9Z8SYtLUa9G2u%2F%2BQlvu2JF9fwidCXq%2BmZJmkkfZTlYUUUfDUxrynpdlvi6zat316bxLEFWPjmYB44whd%2BuioDZCSZE%3D&u2=ExVWsIJFyo8Q25Ik&width=2560');">
    </div>
    <!-- Dark gradient overlay -->
    <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-petra-900/70"></div>

    <div class="relative z-10 text-center text-white px-4 sm:px-6 max-w-4xl mx-auto pt-24 pb-16">
      <p class="uppercase tracking-[0.3em] text-sand-300 text-xs sm:text-sm mb-4 font-semibold" data-i18n="hero.eyebrow">
        Welcome to the Rose City
      </p>

      <h1 class="font-display font-bold text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-tight mb-6" data-i18n="hero.title">
        Discover the Wonders of Petra
      </h1>

      <p class="text-base sm:text-lg md:text-xl text-sand-100/90 mb-10 max-w-2xl mx-auto leading-relaxed" data-i18n="hero.subtitle">
        Experience Jordan's ancient beauty with expert local guides, curated tours, and unforgettable memories that last a lifetime.
      </p>

      <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
        <a href="#packages"
           class="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-petra-500 hover:bg-petra-600 text-white font-semibold shadow-2xl shadow-petra-900/40 transition transform hover:scale-105">
          <i class="fa-solid fa-calendar-check"></i>
          <span data-i18n="hero.cta">Book Your Tour Now</span>
        </a>
        <a href="#packages"
           class="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full border-2 border-white/70 text-white hover:bg-white hover:text-petra-700 font-semibold transition">
          <i class="fa-solid fa-play"></i>
          <span data-i18n="hero.explore">Explore Packages</span>
        </a>
      </div>

      <!-- Trust stats -->
      <div class="mt-14 grid grid-cols-3 gap-4 sm:gap-8 max-w-2xl mx-auto">
        <div>
          <div class="font-display text-2xl sm:text-3xl md:text-4xl font-bold text-sand-300">10K+</div>
          <div class="text-xs sm:text-sm text-white/80 mt-1" data-i18n="hero.stat1">Happy Travelers</div>
        </div>
        <div>
          <div class="font-display text-2xl sm:text-3xl md:text-4xl font-bold text-sand-300">15+</div>
          <div class="text-xs sm:text-sm text-white/80 mt-1" data-i18n="hero.stat2">Years of Experience</div>
        </div>
        <div>
          <div class="font-display text-2xl sm:text-3xl md:text-4xl font-bold text-sand-300">4.9<span class="text-lg">★</span></div>
          <div class="text-xs sm:text-sm text-white/80 mt-1" data-i18n="hero.stat3">Average Rating</div>
        </div>
      </div>
    </div>

    <!-- Scroll indicator -->
    <a href="#packages" class="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/80 hover:text-white text-2xl animate-bounce z-10 hidden sm:block">
      <i class="fa-solid fa-chevron-down"></i>
    </a>
  </section>

  <!-- =========================================================
       TOUR PACKAGES
       ========================================================= -->
  <section id="packages" class="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 bg-white">
    <div class="max-w-7xl mx-auto">
      <!-- Section header -->
      <div class="text-center max-w-2xl mx-auto mb-14">
        <span class="inline-block px-4 py-1 rounded-full bg-petra-100 text-petra-700 text-xs font-bold uppercase tracking-widest mb-4" data-i18n="packages.eyebrow">Our Packages</span>
        <h2 class="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-petra-800 mb-4" data-i18n="packages.title">
          Curated Petra Experiences
        </h2>
        <p class="text-gray-600 text-base sm:text-lg" data-i18n="packages.subtitle">
          Choose the perfect journey. Every package includes destinations, meals, accommodations and private transportation.
        </p>
      </div>

      <!-- Package cards grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

        <!-- ===== Package 1: Essential ===== -->
        <article class="group bg-sand-50 rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl border border-sand-100 transition-all duration-300 hover:-translate-y-2 flex flex-col">
          <div class="relative h-56 overflow-hidden">
            <img src="https://images.unsplash.com/photo-1580418827493-f2b22c0a76cb?auto=format&fit=crop&w=800&q=80"
                 alt="Petra Treasury" class="w-full h-full object-cover group-hover:scale-110 transition duration-500" />
            <div class="absolute top-4 start-4 bg-white/95 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-petra-700 uppercase tracking-wider" data-i18n="packages.essential.badge">1 Day</div>
          </div>
          <div class="p-6 sm:p-7 flex flex-col flex-grow">
            <h3 class="font-display font-bold text-2xl text-petra-800 mb-2" data-i18n="packages.essential.name">Essential Petra</h3>
            <p class="text-gray-600 text-sm mb-5" data-i18n="packages.essential.desc">A perfect introduction to Petra's most iconic sights in one unforgettable day.</p>

            <ul class="space-y-2.5 text-sm text-gray-700 mb-6">
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-location-dot text-petra-500 mt-1"></i><span><strong data-i18n="packages.label.destinations">Destinations:</strong> <span data-i18n="packages.essential.destinations">The Siq, Treasury, Street of Facades</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-utensils text-sand-600 mt-1"></i><span><strong data-i18n="packages.label.meals">Meals:</strong> <span data-i18n="packages.essential.meals">Traditional Bedouin lunch</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-bed text-petra-500 mt-1"></i><span><strong data-i18n="packages.label.stay">Stay:</strong> <span data-i18n="packages.essential.stay">Day trip (no overnight)</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-car text-sand-600 mt-1"></i><span><strong data-i18n="packages.label.transport">Transport:</strong> <span data-i18n="packages.essential.transport">Private A/C car + English driver</span></span></li>
            </ul>

            <div class="mt-auto pt-5 border-t border-sand-200 flex items-end justify-between">
              <div>
                <div class="text-xs text-gray-500 uppercase tracking-wider" data-i18n="packages.label.from">From</div>
                <div class="font-display font-bold text-3xl text-petra-600">$120<span class="text-sm text-gray-500 font-body font-normal ms-1" data-i18n="packages.label.perPerson">/person</span></div>
              </div>
              <button class="book-tour-btn px-5 py-2.5 rounded-full bg-petra-500 hover:bg-petra-600 text-white text-sm font-semibold shadow-md transition"
                      data-tour="Essential Petra"
                      data-i18n="packages.label.book">Book</button>
            </div>
          </div>
        </article>

        <!-- ===== Package 2: Classic (Popular) ===== -->
        <article class="group bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl ring-2 ring-petra-500 transition-all duration-300 hover:-translate-y-2 flex flex-col relative">
          <!-- Popular ribbon -->
          <div class="absolute top-4 end-4 z-10 bg-petra-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg" data-i18n="packages.popular">MOST POPULAR</div>
          <div class="relative h-56 overflow-hidden">
            <img src="https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=800&q=80"
                 alt="Petra Monastery" class="w-full h-full object-cover group-hover:scale-110 transition duration-500" />
            <div class="absolute top-4 start-4 bg-white/95 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-petra-700 uppercase tracking-wider" data-i18n="packages.classic.badge">2 Days</div>
          </div>
          <div class="p-6 sm:p-7 flex flex-col flex-grow">
            <h3 class="font-display font-bold text-2xl text-petra-800 mb-2" data-i18n="packages.classic.name">Classic Petra & Wadi Musa</h3>
            <p class="text-gray-600 text-sm mb-5" data-i18n="packages.classic.desc">Explore Petra by day, sleep under Bedouin skies, and hike to the majestic Monastery.</p>

            <ul class="space-y-2.5 text-sm text-gray-700 mb-6">
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-location-dot text-petra-500 mt-1"></i><span><strong data-i18n="packages.label.destinations">Destinations:</strong> <span data-i18n="packages.classic.destinations">Treasury, Monastery, Royal Tombs, High Place of Sacrifice</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-utensils text-sand-600 mt-1"></i><span><strong data-i18n="packages.label.meals">Meals:</strong> <span data-i18n="packages.classic.meals">Al-Qantarah Restaurant + Bedouin dinner</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-bed text-petra-500 mt-1"></i><span><strong data-i18n="packages.label.stay">Stay:</strong> <span data-i18n="packages.classic.stay">1 night at Mövenpick Petra (4★)</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-car text-sand-600 mt-1"></i><span><strong data-i18n="packages.label.transport">Transport:</strong> <span data-i18n="packages.classic.transport">Private SUV + certified local driver</span></span></li>
            </ul>

            <div class="mt-auto pt-5 border-t border-sand-200 flex items-end justify-between">
              <div>
                <div class="text-xs text-gray-500 uppercase tracking-wider" data-i18n="packages.label.from">From</div>
                <div class="font-display font-bold text-3xl text-petra-600">$280<span class="text-sm text-gray-500 font-body font-normal ms-1" data-i18n="packages.label.perPerson">/person</span></div>
              </div>
              <button class="book-tour-btn px-5 py-2.5 rounded-full bg-petra-500 hover:bg-petra-600 text-white text-sm font-semibold shadow-md transition"
                      data-tour="Classic Petra & Wadi Musa"
                      data-i18n="packages.label.book">Book</button>
            </div>
          </div>
        </article>

        <!-- ===== Package 3: Premium ===== -->
        <article class="group bg-sand-50 rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl border border-sand-100 transition-all duration-300 hover:-translate-y-2 flex flex-col">
          <div class="relative h-56 overflow-hidden">
            <img src="https://sspark.genspark.ai/cfimages?u1=VX8uNGGEEz%2Bm3B7WhqkKPJgl%2F4WQXt9ZlXUqBXfht3JKNDK%2FTnI8CnLdA5maxs3l%2B5yD%2FHmRkVIqxqW%2F7vqfjii%2F5qdD8YQjCD6sSdU%2FI%2BUOPYPMaYowtuVL%2F4f9xw%3D%3D&u2=WfzS%2Bl5rMS%2FWp7D0&width=2560"
                 alt="Petra by Night" class="w-full h-full object-cover group-hover:scale-110 transition duration-500" />
            <div class="absolute top-4 start-4 bg-white/95 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-petra-700 uppercase tracking-wider" data-i18n="packages.premium.badge">3 Days</div>
          </div>
          <div class="p-6 sm:p-7 flex flex-col flex-grow">
            <h3 class="font-display font-bold text-2xl text-petra-800 mb-2" data-i18n="packages.premium.name">Premium Petra & Wadi Rum</h3>
            <p class="text-gray-600 text-sm mb-5" data-i18n="packages.premium.desc">The complete luxury journey: Petra by Night, Wadi Rum jeep safari and 5-star comfort.</p>

            <ul class="space-y-2.5 text-sm text-gray-700 mb-6">
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-location-dot text-petra-500 mt-1"></i><span><strong data-i18n="packages.label.destinations">Destinations:</strong> <span data-i18n="packages.premium.destinations">All of Petra + Petra by Night + Wadi Rum desert</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-utensils text-sand-600 mt-1"></i><span><strong data-i18n="packages.label.meals">Meals:</strong> <span data-i18n="packages.premium.meals">Full-board: My Mom's Recipe + Bedouin Zarb</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-bed text-petra-500 mt-1"></i><span><strong data-i18n="packages.label.stay">Stay:</strong> <span data-i18n="packages.premium.stay">Mövenpick Petra (5★) + Bubble Luxotel Rum</span></span></li>
              <li class="flex items-start gap-2.5"><i class="fa-solid fa-car text-sand-600 mt-1"></i><span><strong data-i18n="packages.label.transport">Transport:</strong> <span data-i18n="packages.premium.transport">Private luxury van + multilingual driver-guide</span></span></li>
            </ul>

            <div class="mt-auto pt-5 border-t border-sand-200 flex items-end justify-between">
              <div>
                <div class="text-xs text-gray-500 uppercase tracking-wider" data-i18n="packages.label.from">From</div>
                <div class="font-display font-bold text-3xl text-petra-600">$540<span class="text-sm text-gray-500 font-body font-normal ms-1" data-i18n="packages.label.perPerson">/person</span></div>
              </div>
              <button class="book-tour-btn px-5 py-2.5 rounded-full bg-petra-500 hover:bg-petra-600 text-white text-sm font-semibold shadow-md transition"
                      data-tour="Premium Petra & Wadi Rum"
                      data-i18n="packages.label.book">Book</button>
            </div>
          </div>
        </article>

      </div>
    </div>
  </section>

  <!-- =========================================================
       TOUR GUIDES
       ========================================================= -->
  <section id="guides" class="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 bg-sand-50">
    <div class="max-w-7xl mx-auto">
      <div class="text-center max-w-2xl mx-auto mb-14">
        <span class="inline-block px-4 py-1 rounded-full bg-sand-200 text-sand-700 text-xs font-bold uppercase tracking-widest mb-4" data-i18n="guides.eyebrow">Meet the Team</span>
        <h2 class="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-petra-800 mb-4" data-i18n="guides.title">
          Our Certified Tour Guides
        </h2>
        <p class="text-gray-600 text-base sm:text-lg" data-i18n="guides.subtitle">
          Local experts, passionate storytellers. Book directly with the guide that matches your journey.
        </p>
      </div>

      <!-- Guides grid - populated dynamically by JS so ratings, reviews, availability can be edited from one place -->
      <div id="guides-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
        <!-- Cards injected by /static/app.js -->
      </div>
    </div>
  </section>

  <!-- =========================================================
       TESTIMONIALS
       ========================================================= -->
  <section id="testimonials" class="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 bg-white">
    <div class="max-w-7xl mx-auto">
      <div class="text-center max-w-2xl mx-auto mb-14">
        <span class="inline-block px-4 py-1 rounded-full bg-petra-100 text-petra-700 text-xs font-bold uppercase tracking-widest mb-4" data-i18n="testimonials.eyebrow">Testimonials</span>
        <h2 class="font-display font-bold text-3xl sm:text-4xl md:text-5xl text-petra-800 mb-4" data-i18n="testimonials.title">
          Loved by Travelers Worldwide
        </h2>
        <p class="text-gray-600 text-base sm:text-lg" data-i18n="testimonials.subtitle">
          Real stories from global and local guests who trusted us with their Jordan adventure.
        </p>
      </div>

      <!-- Testimonials grid - populated dynamically for easy editing -->
      <div id="testimonials-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        <!-- Cards injected by /static/app.js -->
      </div>
    </div>
  </section>

  <!-- =========================================================
       CTA STRIP
       ========================================================= -->
  <section class="relative py-16 sm:py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
    <div class="absolute inset-0 bg-cover bg-center"
         style="background-image: url('https://sspark.genspark.ai/cfimages?u1=w3kmrN9N%2BM2Mwv0B28wbpJ9psoAfxIOOYN38ZVpJ8sh6OCnhaRGWWIhIqxuuFw9lrCNFvjVcwoplXTW5EslFfNo3IOcHYx%2BSkf3IuuIklMUBALIPM6JGq56Dp0tz3xvYrSwNPsQkq2lNdK2TNSNDQQ%3D%3D&u2=WKxtBZaqzideER8S&width=2560');">
    </div>
    <div class="absolute inset-0 bg-gradient-to-r from-petra-800/90 to-petra-600/80"></div>
    <div class="relative max-w-4xl mx-auto text-center text-white">
      <h3 class="font-display font-bold text-3xl sm:text-4xl md:text-5xl mb-4" data-i18n="cta.title">Ready to Walk Through the Siq?</h3>
      <p class="text-sand-100/90 text-base sm:text-lg mb-8 max-w-2xl mx-auto" data-i18n="cta.subtitle">
        Let us craft the perfect Petra experience for you. Talk to a local expert today.
      </p>
      <a href="#contact" class="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-white text-petra-700 font-bold hover:bg-sand-100 transition shadow-2xl">
        <i class="fa-solid fa-phone"></i>
        <span data-i18n="cta.button">Contact Us Now</span>
      </a>
    </div>
  </section>

  <!-- =========================================================
       FOOTER
       ========================================================= -->
  <footer id="contact" class="bg-petra-900 text-sand-100 pt-16 pb-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">

        <!-- Brand column -->
        <div>
          <div class="flex items-center gap-3 mb-4">
            <!-- Logo Here -->
            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-petra-500 to-sand-500 flex items-center justify-center text-white">
              <i class="fa-solid fa-mountain-sun"></i>
            </div>
            <div class="font-display font-bold text-lg text-white" data-i18n="brand.name">Jordan Inspiration Tours</div>
          </div>
          <p class="text-sm text-sand-200/80 leading-relaxed mb-5" data-i18n="footer.about">
            Locally owned Jordanian tour operator specializing in authentic Petra experiences since 2009.
          </p>
          <div class="flex items-center gap-3">
            <a href="#" aria-label="Facebook" class="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-petra-500 transition"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#" aria-label="Instagram" class="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-petra-500 transition"><i class="fa-brands fa-instagram"></i></a>
            <a href="#" aria-label="TripAdvisor" class="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-petra-500 transition"><i class="fa-brands fa-tripadvisor"></i></a>
            <a href="#" aria-label="WhatsApp" class="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-petra-500 transition"><i class="fa-brands fa-whatsapp"></i></a>
            <a href="#" aria-label="YouTube" class="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-petra-500 transition"><i class="fa-brands fa-youtube"></i></a>
          </div>
        </div>

        <!-- Contact -->
        <div>
          <h4 class="font-display font-bold text-white text-lg mb-4" data-i18n="footer.contactTitle">Contact</h4>
          <ul class="space-y-3 text-sm text-sand-200/90">
            <li class="flex items-start gap-3"><i class="fa-solid fa-phone text-petra-400 mt-1"></i><a href="tel:+962795550123" dir="ltr" class="hover:text-white">+962 79 555 0123</a></li>
            <li class="flex items-start gap-3"><i class="fa-solid fa-envelope text-petra-400 mt-1"></i><a href="mailto:info@jordaninspirationtours.com" class="hover:text-white break-all">info@jordaninspirationtours.com</a></li>
            <li class="flex items-start gap-3"><i class="fa-solid fa-location-dot text-petra-400 mt-1"></i><span data-i18n="footer.address">Tourism Street, Wadi Musa, Jordan</span></li>
          </ul>
        </div>

        <!-- Working hours -->
        <div>
          <h4 class="font-display font-bold text-white text-lg mb-4" data-i18n="footer.hoursTitle">Working Hours</h4>
          <ul class="space-y-2 text-sm text-sand-200/90">
            <li class="flex items-center justify-between gap-3"><span data-i18n="footer.days.satThu">Sat - Thu</span><span dir="ltr">08:00 - 20:00</span></li>
            <li class="flex items-center justify-between gap-3"><span data-i18n="footer.days.fri">Friday</span><span dir="ltr">10:00 - 16:00</span></li>
            <li class="flex items-center justify-between gap-3"><span data-i18n="footer.days.support">24/7 Support</span><span class="text-green-400 font-semibold"><i class="fa-solid fa-circle text-[8px] me-1"></i><span data-i18n="footer.online">Online</span></span></li>
          </ul>
        </div>

        <!-- Quick links -->
        <div>
          <h4 class="font-display font-bold text-white text-lg mb-4" data-i18n="footer.linksTitle">Quick Links</h4>
          <ul class="space-y-2 text-sm text-sand-200/90">
            <li><a href="#home"         class="hover:text-white transition" data-i18n="nav.home">Home</a></li>
            <li><a href="#packages"     class="hover:text-white transition" data-i18n="nav.packages">Packages</a></li>
            <li><a href="#guides"       class="hover:text-white transition" data-i18n="nav.guides">Guides</a></li>
            <li><a href="#testimonials" class="hover:text-white transition" data-i18n="nav.testimonials">Testimonials</a></li>
          </ul>
        </div>
      </div>

      <div class="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-sand-300/70">
        <p>&copy; <span id="year"></span> Jordan Inspiration Tours. <span data-i18n="footer.rights">All rights reserved.</span></p>
        <p data-i18n="footer.madeIn">Made with ❤ in Wadi Musa, Jordan</p>
      </div>
    </div>
  </footer>

  <!-- =========================================================
       BOOKING MODAL
       ========================================================= -->
  <div id="booking-modal"
       class="fixed inset-0 z-[100] hidden items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
       aria-hidden="true" role="dialog" aria-labelledby="booking-title">
    <div class="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-[fadeIn_0.25s_ease-out]">
      <!-- Modal header -->
      <div class="relative bg-gradient-to-r from-petra-600 to-petra-500 text-white px-6 py-5">
        <h3 id="booking-title" class="font-display font-bold text-xl sm:text-2xl" data-i18n="modal.title">Book Your Experience</h3>
        <p class="text-sand-100/90 text-sm mt-1" id="booking-subtitle" data-i18n="modal.subtitle">Fill in your details and we'll confirm within 24 hours.</p>
        <button id="modal-close"
                class="absolute top-4 end-4 w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition"
                aria-label="Close">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>

      <!-- Modal body / form -->
      <form id="booking-form" class="p-6 space-y-4">
        <!-- Selected package / guide readonly display -->
        <div id="booking-context" class="hidden bg-sand-50 border border-sand-200 rounded-xl px-4 py-3 text-sm">
          <span class="text-gray-500" data-i18n="modal.selection">Selection:</span>
          <span id="booking-context-value" class="font-semibold text-petra-700 ms-1"></span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label class="block">
            <span class="text-sm font-medium text-gray-700" data-i18n="modal.name">Full Name</span>
            <input type="text" name="name" required
                   class="mt-1 w-full rounded-xl border border-sand-300 focus:border-petra-500 focus:ring-2 focus:ring-petra-200 px-4 py-2.5 outline-none transition" />
          </label>
          <label class="block">
            <span class="text-sm font-medium text-gray-700" data-i18n="modal.email">Email</span>
            <input type="email" name="email" required
                   class="mt-1 w-full rounded-xl border border-sand-300 focus:border-petra-500 focus:ring-2 focus:ring-petra-200 px-4 py-2.5 outline-none transition" />
          </label>
        </div>

        <label class="block">
          <span class="text-sm font-medium text-gray-700" data-i18n="modal.phone">Phone</span>
          <input type="tel" name="phone" required dir="ltr"
                 class="mt-1 w-full rounded-xl border border-sand-300 focus:border-petra-500 focus:ring-2 focus:ring-petra-200 px-4 py-2.5 outline-none transition" />
        </label>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label class="block">
            <span class="text-sm font-medium text-gray-700" data-i18n="modal.date">Date</span>
            <input type="date" name="date" required
                   class="mt-1 w-full rounded-xl border border-sand-300 focus:border-petra-500 focus:ring-2 focus:ring-petra-200 px-4 py-2.5 outline-none transition" />
          </label>
          <label class="block">
            <span class="text-sm font-medium text-gray-700" data-i18n="modal.time">Time</span>
            <input type="time" name="time" required
                   class="mt-1 w-full rounded-xl border border-sand-300 focus:border-petra-500 focus:ring-2 focus:ring-petra-200 px-4 py-2.5 outline-none transition" />
          </label>
        </div>

        <label class="block">
          <span class="text-sm font-medium text-gray-700" data-i18n="modal.guests">Number of Guests</span>
          <input type="number" name="guests" min="1" max="20" value="2" required
                 class="mt-1 w-full rounded-xl border border-sand-300 focus:border-petra-500 focus:ring-2 focus:ring-petra-200 px-4 py-2.5 outline-none transition" />
        </label>

        <label class="block">
          <span class="text-sm font-medium text-gray-700" data-i18n="modal.notes">Notes (optional)</span>
          <textarea name="notes" rows="3"
                    class="mt-1 w-full rounded-xl border border-sand-300 focus:border-petra-500 focus:ring-2 focus:ring-petra-200 px-4 py-2.5 outline-none transition resize-none"></textarea>
        </label>

        <!-- Success message -->
        <div id="booking-success" class="hidden bg-green-50 border border-green-200 text-green-800 rounded-xl px-4 py-3 text-sm">
          <i class="fa-solid fa-circle-check me-2"></i>
          <span data-i18n="modal.success">Thank you! Your booking request has been received. We'll be in touch shortly.</span>
        </div>

        <button type="submit"
                class="w-full py-3.5 rounded-full bg-petra-500 hover:bg-petra-600 text-white font-bold shadow-lg transition flex items-center justify-center gap-2">
          <i class="fa-solid fa-paper-plane"></i>
          <span data-i18n="modal.submit">Confirm Booking</span>
        </button>
      </form>
    </div>
  </div>

  <!-- App logic (translations, language switcher, guides & testimonials data, booking modal) -->
  <script src="/static/app.js"></script>
</body>
</html>`)
})

export default app
