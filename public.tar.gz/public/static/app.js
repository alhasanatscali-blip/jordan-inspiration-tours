/* =========================================================
   Jordan Inspiration Tours - Client-side logic
   ---------------------------------------------------------
   This single file contains:
     1. TRANSLATIONS  - key/value dictionary for EN + AR
     2. GUIDES        - tour guide roster (edit here to add/remove guides)
     3. TESTIMONIALS  - client testimonials data
     4. renderGuides / renderTestimonials
     5. Language switcher (updates <html lang>, dir, and text)
     6. Booking modal (opens for both tour packages and specific guides)
     7. Small UX helpers (mobile menu, sticky navbar, current year)
   ========================================================= */

/* =========================================================
   1. TRANSLATIONS
   =========================================================
   To add a new language:
     - copy an existing block, translate values, keep the same keys
     - add the language to LANGS below and update the switcher
*/
const TRANSLATIONS = {
  en: {
    'meta.title': 'Jordan Inspiration Tours - Petra Experiences',

    'brand.name':    'Jordan Inspiration Tours',
    'brand.tagline': 'Petra & Beyond',

    'nav.home':         'Home',
    'nav.packages':     'Packages',
    'nav.guides':       'Guides',
    'nav.testimonials': 'Testimonials',
    'nav.contact':      'Contact',
    'nav.book':         'Book Now',

    'hero.eyebrow':  'Welcome to the Rose City',
    'hero.title':    'Discover the Wonders of Petra',
    'hero.subtitle': "Experience Jordan's ancient beauty with expert local guides, curated tours, and unforgettable memories that last a lifetime.",
    'hero.cta':      'Book Your Tour Now',
    'hero.explore':  'Explore Packages',
    'hero.stat1':    'Happy Travelers',
    'hero.stat2':    'Years of Experience',
    'hero.stat3':    'Average Rating',

    'packages.eyebrow':  'Our Packages',
    'packages.title':    'Curated Petra Experiences',
    'packages.subtitle': 'Choose the perfect journey. Every package includes destinations, meals, accommodations and private transportation.',
    'packages.popular':  'MOST POPULAR',
    'packages.label.destinations': 'Destinations:',
    'packages.label.meals':        'Meals:',
    'packages.label.stay':         'Stay:',
    'packages.label.transport':    'Transport:',
    'packages.label.from':         'From',
    'packages.label.perPerson':    '/person',
    'packages.label.book':         'Book',

    'packages.essential.badge':        '1 Day',
    'packages.essential.name':         'Essential Petra',
    'packages.essential.desc':         "A perfect introduction to Petra's most iconic sights in one unforgettable day.",
    'packages.essential.destinations': 'The Siq, Treasury, Street of Facades',
    'packages.essential.meals':        'Traditional Bedouin lunch',
    'packages.essential.stay':         'Day trip (no overnight)',
    'packages.essential.transport':    'Private A/C car + English driver',

    'packages.classic.badge':        '2 Days',
    'packages.classic.name':         'Classic Petra & Wadi Musa',
    'packages.classic.desc':         'Explore Petra by day, sleep under Bedouin skies, and hike to the majestic Monastery.',
    'packages.classic.destinations': 'Treasury, Monastery, Royal Tombs, High Place of Sacrifice',
    'packages.classic.meals':        'Al-Qantarah Restaurant + Bedouin dinner',
    'packages.classic.stay':         '1 night at Mövenpick Petra (4★)',
    'packages.classic.transport':    'Private SUV + certified local driver',

    'packages.premium.badge':        '3 Days',
    'packages.premium.name':         'Premium Petra & Wadi Rum',
    'packages.premium.desc':         'The complete luxury journey: Petra by Night, Wadi Rum jeep safari and 5-star comfort.',
    'packages.premium.destinations': 'All of Petra + Petra by Night + Wadi Rum desert',
    'packages.premium.meals':        "Full-board: My Mom's Recipe + Bedouin Zarb",
    'packages.premium.stay':         'Mövenpick Petra (5★) + Bubble Luxotel Rum',
    'packages.premium.transport':    'Private luxury van + multilingual driver-guide',

    'guides.eyebrow':  'Meet the Team',
    'guides.title':    'Our Certified Tour Guides',
    'guides.subtitle': 'Local experts, passionate storytellers. Book directly with the guide that matches your journey.',
    'guides.available':   'Available',
    'guides.unavailable': 'Unavailable',
    'guides.reviews':     'reviews',
    'guides.book':        'Book this Guide',
    'guides.bookedUp':    'Fully Booked',
    'guides.speaks':      'Speaks',
    'guides.experience':  'yrs exp.',

    'testimonials.eyebrow':  'Testimonials',
    'testimonials.title':    'Loved by Travelers Worldwide',
    'testimonials.subtitle': 'Real stories from global and local guests who trusted us with their Jordan adventure.',

    'cta.title':    'Ready to Walk Through the Siq?',
    'cta.subtitle': 'Let us craft the perfect Petra experience for you. Talk to a local expert today.',
    'cta.button':   'Contact Us Now',

    'footer.about':        'Locally owned Jordanian tour operator specializing in authentic Petra experiences since 2009.',
    'footer.contactTitle': 'Contact',
    'footer.hoursTitle':   'Working Hours',
    'footer.linksTitle':   'Quick Links',
    'footer.address':      'Tourism Street, Wadi Musa, Jordan',
    'footer.days.satThu':  'Sat - Thu',
    'footer.days.fri':     'Friday',
    'footer.days.support': '24/7 Support',
    'footer.online':       'Online',
    'footer.rights':       'All rights reserved.',
    'footer.madeIn':       'Made with ❤ in Wadi Musa, Jordan',

    'modal.title':      'Book Your Experience',
    'modal.subtitle':   "Fill in your details and we'll confirm within 24 hours.",
    'modal.selection':  'Selection:',
    'modal.name':       'Full Name',
    'modal.email':      'Email',
    'modal.phone':      'Phone',
    'modal.date':       'Date',
    'modal.time':       'Time',
    'modal.guests':     'Number of Guests',
    'modal.notes':      'Notes (optional)',
    'modal.submit':     'Confirm Booking',
    'modal.success':    "Thank you! Your booking request has been received. We'll be in touch shortly.",
  },

  ar: {
    'meta.title': 'جوردان إنسبيريشن تورز - تجارب البتراء',

    'brand.name':    'جوردان إنسبيريشن تورز',
    'brand.tagline': 'البتراء وما بعدها',

    'nav.home':         'الرئيسية',
    'nav.packages':     'الباقات',
    'nav.guides':       'المرشدون',
    'nav.testimonials': 'آراء الزوار',
    'nav.contact':      'تواصل معنا',
    'nav.book':         'احجز الآن',

    'hero.eyebrow':  'أهلاً بك في المدينة الوردية',
    'hero.title':    'اكتشف عجائب البتراء',
    'hero.subtitle': 'عِش جمال الأردن العريق مع مرشدين محليين خبراء، وجولات مُنسَّقة بعناية، وذكريات لا تُنسى تدوم مدى الحياة.',
    'hero.cta':      'احجز رحلتك الآن',
    'hero.explore':  'استكشف الباقات',
    'hero.stat1':    'مسافر سعيد',
    'hero.stat2':    'سنة من الخبرة',
    'hero.stat3':    'متوسط التقييم',

    'packages.eyebrow':  'باقاتنا',
    'packages.title':    'تجارب البتراء المُنسَّقة',
    'packages.subtitle': 'اختر رحلتك المثالية. كل باقة تشمل المواقع، الوجبات، الإقامة، والنقل الخاص.',
    'packages.popular':  'الأكثر شعبية',
    'packages.label.destinations': 'الوجهات:',
    'packages.label.meals':        'الوجبات:',
    'packages.label.stay':         'الإقامة:',
    'packages.label.transport':    'النقل:',
    'packages.label.from':         'ابتداءً من',
    'packages.label.perPerson':    '/للشخص',
    'packages.label.book':         'احجز',

    'packages.essential.badge':        'يوم واحد',
    'packages.essential.name':         'البتراء الأساسية',
    'packages.essential.desc':         'مقدمة مثالية لأشهر معالم البتراء في يوم واحد لا يُنسى.',
    'packages.essential.destinations': 'السيق، الخزنة، شارع الواجهات',
    'packages.essential.meals':        'غداء بدوي تقليدي',
    'packages.essential.stay':         'رحلة يومية (بدون مبيت)',
    'packages.essential.transport':    'سيارة خاصة مكيفة + سائق يتحدث الإنجليزية',

    'packages.classic.badge':        'يومان',
    'packages.classic.name':         'البتراء الكلاسيكية ووادي موسى',
    'packages.classic.desc':         'استكشف البتراء نهاراً، وبتْ تحت سماء البدو، وتسلق إلى الدير المهيب.',
    'packages.classic.destinations': 'الخزنة، الدير، القبور الملكية، مذبح القربان',
    'packages.classic.meals':        'مطعم القنطرة + عشاء بدوي',
    'packages.classic.stay':         'ليلة في فندق موفنبيك البتراء (٤ نجوم)',
    'packages.classic.transport':    'سيارة دفع رباعي خاصة + سائق محلي معتمد',

    'packages.premium.badge':        'ثلاثة أيام',
    'packages.premium.name':         'البتراء ووادي رم الفاخرة',
    'packages.premium.desc':         'الرحلة الفاخرة الكاملة: البتراء ليلاً، سفاري جيب في وادي رم، وراحة الخمس نجوم.',
    'packages.premium.destinations': 'كل البتراء + البتراء ليلاً + صحراء وادي رم',
    'packages.premium.meals':        'إقامة كاملة: مطعم ماي مامز ريسيبي + زَرْب بدوي',
    'packages.premium.stay':         'موفنبيك البتراء (٥ نجوم) + فندق ببل لوكسوتيل رم',
    'packages.premium.transport':    'حافلة فاخرة خاصة + سائق ومرشد متعدد اللغات',

    'guides.eyebrow':  'تعرّف على الفريق',
    'guides.title':    'مرشدونا السياحيون المعتمدون',
    'guides.subtitle': 'خبراء محليون ورواة شغوفون. احجز مباشرة مع المرشد الذي يناسب رحلتك.',
    'guides.available':   'متاح حالياً',
    'guides.unavailable': 'غير متاح',
    'guides.reviews':     'تقييم',
    'guides.book':        'احجز هذا الدليل',
    'guides.bookedUp':    'محجوز بالكامل',
    'guides.speaks':      'يتحدث',
    'guides.experience':  'سنة خبرة',

    'testimonials.eyebrow':  'آراء الزوار',
    'testimonials.title':    'محبوبون من المسافرين حول العالم',
    'testimonials.subtitle': 'قصص حقيقية من ضيوفنا العرب والأجانب الذين وثقوا بنا في مغامرتهم الأردنية.',

    'cta.title':    'هل أنت مستعد للسير عبر السيق؟',
    'cta.subtitle': 'دعنا نصمم لك تجربة البتراء المثالية. تحدث مع خبير محلي اليوم.',
    'cta.button':   'تواصل معنا الآن',

    'footer.about':        'شركة سياحية أردنية محلية متخصصة في تجارب البتراء الأصيلة منذ عام 2009.',
    'footer.contactTitle': 'تواصل معنا',
    'footer.hoursTitle':   'ساعات العمل',
    'footer.linksTitle':   'روابط سريعة',
    'footer.address':      'شارع السياحة، وادي موسى، الأردن',
    'footer.days.satThu':  'السبت - الخميس',
    'footer.days.fri':     'الجمعة',
    'footer.days.support': 'دعم على مدار الساعة',
    'footer.online':       'متصل',
    'footer.rights':       'جميع الحقوق محفوظة.',
    'footer.madeIn':       'صُنع بحب ❤ في وادي موسى، الأردن',

    'modal.title':      'احجز تجربتك',
    'modal.subtitle':   'املأ بياناتك وسنؤكد الحجز خلال 24 ساعة.',
    'modal.selection':  'الاختيار:',
    'modal.name':       'الاسم الكامل',
    'modal.email':      'البريد الإلكتروني',
    'modal.phone':      'رقم الهاتف',
    'modal.date':       'التاريخ',
    'modal.time':       'الوقت',
    'modal.guests':     'عدد الأشخاص',
    'modal.notes':      'ملاحظات (اختياري)',
    'modal.submit':     'تأكيد الحجز',
    'modal.success':    'شكراً لك! تم استلام طلب حجزك وسنتواصل معك قريباً.',
  }
};

/* =========================================================
   2. GUIDES data
   =========================================================
   Edit this list to add, remove or update guides.
   `name` and `bio` can be objects { en, ar } for translation.
*/
const GUIDES = [
  {
    id: 'omar',
    name:      { en: 'Omar Al-Bedoul',  ar: 'عمر البدول' },
    languages: { en: 'English, Arabic, Spanish', ar: 'الإنجليزية، العربية، الإسبانية' },
    photo:     'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    experience: 12,
    rating: 5.0,
    reviewsCount: 214,
    available: true,
    review: {
      en: "Omar's stories brought every stone to life. Best guide I've ever had!",
      ar: 'قصص عمر أحيت كل حجر في البتراء. أفضل دليل قابلته على الإطلاق!'
    }
  },
  {
    id: 'layla',
    name:      { en: 'Layla Nawafleh',  ar: 'ليلى النوافلة' },
    languages: { en: 'English, Arabic, French', ar: 'الإنجليزية، العربية، الفرنسية' },
    photo:     'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80',
    experience: 8,
    rating: 4.9,
    reviewsCount: 158,
    available: true,
    review: {
      en: 'Layla knows every hidden corner of Petra. Deeply knowledgeable and warm.',
      ar: 'ليلى تعرف كل زاوية خفية في البتراء. معرفة عميقة ودفء حقيقي.'
    }
  },
  {
    id: 'khaled',
    name:      { en: 'Khaled Twaissi',  ar: 'خالد الطويسي' },
    languages: { en: 'English, Arabic, German', ar: 'الإنجليزية، العربية، الألمانية' },
    photo:     'https://images.unsplash.com/photo-1531384441138-2736e62e0919?auto=format&fit=crop&w=400&q=80',
    experience: 15,
    rating: 4.8,
    reviewsCount: 302,
    available: false,
    review: {
      en: 'A walking encyclopedia of Nabatean history. Absolutely worth the wait!',
      ar: 'موسوعة متنقلة عن تاريخ الأنباط. يستحق الانتظار بالتأكيد!'
    }
  },
  {
    id: 'rania',
    name:      { en: 'Rania Al-Amarat', ar: 'رانيا العمارات' },
    languages: { en: 'English, Arabic, Italian', ar: 'الإنجليزية، العربية، الإيطالية' },
    photo:     'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80',
    experience: 6,
    rating: 4.9,
    reviewsCount: 97,
    available: true,
    review: {
      en: 'Rania made our family trip magical - she connected beautifully with the kids.',
      ar: 'رانيا حوّلت رحلة عائلتنا إلى سحر. تواصلت مع الأطفال بشكل رائع.'
    }
  },
];

/* =========================================================
   3. TESTIMONIALS data
   ========================================================= */
const TESTIMONIALS = [
  {
    name:    { en: 'Emma Roberts', ar: 'إيما روبرتس' },
    country: { en: 'United Kingdom', ar: 'المملكة المتحدة' },
    photo:   'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    text: {
      en: 'Absolutely magical from start to finish. The Petra by Night experience was surreal, and our guide made every moment memorable. Highly recommend Jordan Inspiration Tours!',
      ar: 'رحلة سحرية من البداية إلى النهاية. تجربة البتراء ليلاً كانت خيالية، وجعل مرشدنا كل لحظة لا تُنسى. أنصح بشدة بشركة جوردان إنسبيريشن تورز!'
    }
  },
  {
    name:    { en: 'Ahmed Al-Farsi', ar: 'أحمد الفارسي' },
    country: { en: 'United Arab Emirates', ar: 'الإمارات العربية المتحدة' },
    photo:   'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    text: {
      en: "Professional, punctual, and passionate. We felt like family. Wadi Rum under the stars was the highlight of our entire year.",
      ar: 'احترافيون، ملتزمون بالمواعيد، وشغوفون بعملهم. شعرنا وكأننا مع العائلة. وادي رم تحت النجوم كان أجمل ما في عامنا.'
    }
  },
  {
    name:    { en: 'Sophie Martin', ar: 'صوفي مارتان' },
    country: { en: 'France', ar: 'فرنسا' },
    photo:   'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    text: {
      en: "The best organized tour I've ever taken. Great hotels, delicious food, and a driver who felt like a friend. Merci beaucoup!",
      ar: 'أفضل جولة مُنظَّمة قمت بها في حياتي. فنادق ممتازة، طعام لذيذ، وسائق شعرنا معه وكأنه صديق قديم. شكراً جزيلاً!'
    }
  },
  {
    name:    { en: 'Yuki Tanaka', ar: 'يوكي تاناكا' },
    country: { en: 'Japan', ar: 'اليابان' },
    photo:   'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    text: {
      en: 'Every detail was perfectly planned. The Monastery hike at sunset - unforgettable. Thank you for the memories!',
      ar: 'كل التفاصيل خُطط لها بإتقان. صعود الدير عند الغروب كان تجربة لا تُنسى. شكراً على هذه الذكريات!'
    }
  },
  {
    name:    { en: 'Michael Chen', ar: 'مايكل تشين' },
    country: { en: 'Canada', ar: 'كندا' },
    photo:   'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80',
    rating: 4,
    text: {
      en: 'Great value for a 3-day package. The Bedouin dinner was a personal favorite. Would book again in a heartbeat.',
      ar: 'قيمة ممتازة مقابل باقة الثلاثة أيام. العشاء البدوي كان المفضل لدي. سأحجز معهم مرة أخرى دون تردد.'
    }
  },
  {
    name:    { en: 'Fatima Hassan', ar: 'فاطمة حسن' },
    country: { en: 'Egypt', ar: 'مصر' },
    photo:   'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    text: {
      en: 'As an Arabic speaker, I loved being able to hear the stories in both languages. Truly authentic Jordanian hospitality.',
      ar: 'كوني ناطقة بالعربية، أحببت الاستماع إلى القصص بكلتا اللغتين. ضيافة أردنية أصيلة بحق.'
    }
  }
];

/* =========================================================
   4. Renderers
   ========================================================= */

/** Build the "X out of 5" star icons */
function renderStars(rating) {
  const full = Math.round(rating);
  let html = '<div class="stars flex items-center gap-0.5 text-sm">';
  for (let i = 1; i <= 5; i++) {
    html += `<i class="fa-solid fa-star ${i <= full ? '' : 'opacity-30'}"></i>`;
  }
  html += '</div>';
  return html;
}

/** Render tour guide cards */
function renderGuides(lang) {
  const t = TRANSLATIONS[lang];
  const grid = document.getElementById('guides-grid');
  if (!grid) return;

  grid.innerHTML = GUIDES.map(g => {
    const isAvail = g.available;
    const statusText   = isAvail ? t['guides.available'] : t['guides.unavailable'];
    const statusColor  = isAvail ? 'bg-green-100 text-green-700 border-green-200'
                                 : 'bg-gray-100 text-gray-500 border-gray-200';
    const statusDot    = isAvail ? 'bg-green-500 animate-pulse' : 'bg-gray-400';
    const btnText      = isAvail ? t['guides.book'] : t['guides.bookedUp'];
    const btnClass     = isAvail
      ? 'bg-petra-500 hover:bg-petra-600 text-white cursor-pointer'
      : 'bg-gray-200 text-gray-500 cursor-not-allowed';

    return `
      <article class="bg-white rounded-3xl shadow-md hover:shadow-2xl border border-sand-100 overflow-hidden transition-all duration-300 hover:-translate-y-1 flex flex-col">
        <!-- Photo + availability badge -->
        <div class="relative">
          <img src="${g.photo}" alt="${g.name[lang]}"
               class="w-full h-56 sm:h-52 object-cover" loading="lazy" />
          <div class="absolute top-3 end-3 flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${statusColor} backdrop-blur bg-white/90">
            <span class="w-2 h-2 rounded-full ${statusDot}"></span>
            ${statusText}
          </div>
        </div>

        <div class="p-5 flex flex-col flex-grow">
          <h3 class="font-display font-bold text-lg text-petra-800">${g.name[lang]}</h3>

          <div class="flex items-center gap-2 mt-1">
            ${renderStars(g.rating)}
            <span class="text-xs text-gray-500">${g.rating.toFixed(1)} · ${g.reviewsCount} ${t['guides.reviews']}</span>
          </div>

          <div class="text-xs text-gray-600 mt-3 space-y-1">
            <div><i class="fa-solid fa-language text-petra-400 me-1"></i>${t['guides.speaks']}: ${g.languages[lang]}</div>
            <div><i class="fa-solid fa-briefcase text-sand-500 me-1"></i>${g.experience} ${t['guides.experience']}</div>
          </div>

          <blockquote class="text-xs italic text-gray-600 mt-4 border-s-2 border-petra-300 ps-3">
            "${g.review[lang]}"
          </blockquote>

          <button class="book-guide-btn mt-5 w-full py-2.5 rounded-full text-sm font-semibold shadow-sm transition ${btnClass}"
                  data-guide-id="${g.id}"
                  data-guide-name="${g.name[lang]}"
                  ${isAvail ? '' : 'disabled'}>
            <i class="fa-solid ${isAvail ? 'fa-calendar-plus' : 'fa-ban'} me-1"></i>
            ${btnText}
          </button>
        </div>
      </article>
    `;
  }).join('');
}

/** Render testimonials cards */
function renderTestimonials(lang) {
  const grid = document.getElementById('testimonials-grid');
  if (!grid) return;

  grid.innerHTML = TESTIMONIALS.map(tst => `
    <article class="bg-sand-50 rounded-3xl p-6 sm:p-7 border border-sand-100 shadow-sm hover:shadow-lg transition duration-300 flex flex-col">
      <div class="flex items-center gap-2 text-petra-500 mb-3">
        <i class="fa-solid fa-quote-left text-2xl opacity-60"></i>
      </div>
      <p class="text-sm sm:text-base text-gray-700 leading-relaxed flex-grow">
        "${tst.text[lang]}"
      </p>
      <div class="mt-5 pt-5 border-t border-sand-200 flex items-center gap-3">
        <img src="${tst.photo}" alt="${tst.name[lang]}" class="w-12 h-12 rounded-full object-cover ring-2 ring-petra-200" loading="lazy" />
        <div class="flex-grow">
          <div class="font-semibold text-petra-800 text-sm">${tst.name[lang]}</div>
          <div class="text-xs text-gray-500">${tst.country[lang]}</div>
        </div>
        ${renderStars(tst.rating)}
      </div>
    </article>
  `).join('');
}

/* =========================================================
   5. Language switcher
   =========================================================
   - Reads user preference from localStorage
   - Updates <html lang> and <html dir> (rtl/ltr)
   - Iterates through every element with [data-i18n] and swaps text
*/
const LANGS = ['en', 'ar'];

function applyLanguage(lang) {
  if (!TRANSLATIONS[lang]) lang = 'en';
  const dict = TRANSLATIONS[lang];

  // Update <html> attributes for accessibility and CSS RTL selectors
  document.documentElement.lang = lang;
  document.documentElement.dir  = (lang === 'ar') ? 'rtl' : 'ltr';

  // Persist preference
  try { localStorage.setItem('jit_lang', lang); } catch (e) { /* ignore */ }

  // Replace every element that has a data-i18n key
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key] !== undefined) {
      // If element is <title>, set textContent; if input placeholder, handle separately
      el.textContent = dict[key];
    }
  });

  // Update the language switcher label to show the OTHER language
  const switcherLabel = document.getElementById('lang-switcher-label');
  if (switcherLabel) {
    switcherLabel.textContent = (lang === 'en') ? 'العربية' : 'English';
  }

  // Re-render dynamic sections that depend on language
  renderGuides(lang);
  renderTestimonials(lang);
}

function toggleLanguage() {
  const current = document.documentElement.lang || 'en';
  const next    = current === 'en' ? 'ar' : 'en';
  applyLanguage(next);
}

/* =========================================================
   6. Booking modal
   ========================================================= */
const modal          = document.getElementById('booking-modal');
const modalCloseBtn  = document.getElementById('modal-close');
const modalCtx       = document.getElementById('booking-context');
const modalCtxValue  = document.getElementById('booking-context-value');
const bookingForm    = document.getElementById('booking-form');
const bookingSuccess = document.getElementById('booking-success');

function openBookingModal(selection) {
  if (!modal) return;

  // Show / hide "Selection:" summary
  if (selection) {
    modalCtx.classList.remove('hidden');
    modalCtxValue.textContent = selection;
  } else {
    modalCtx.classList.add('hidden');
  }

  bookingSuccess.classList.add('hidden');
  bookingForm.reset();
  // Restore default guest count after reset
  bookingForm.querySelector('[name="guests"]').value = 2;

  modal.classList.remove('hidden');
  modal.classList.add('flex');
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden'; // lock background scroll
}

function closeBookingModal() {
  if (!modal) return;
  modal.classList.add('hidden');
  modal.classList.remove('flex');
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}

/* =========================================================
   7. Initialization on DOMContentLoaded
   ========================================================= */
document.addEventListener('DOMContentLoaded', () => {

  // ---- Language: restore preference (default: en)
  let savedLang = 'en';
  try {
    const stored = localStorage.getItem('jit_lang');
    if (stored && LANGS.includes(stored)) savedLang = stored;
  } catch (e) { /* ignore */ }
  applyLanguage(savedLang);

  // ---- Language switcher button
  document.getElementById('lang-switcher').addEventListener('click', toggleLanguage);

  // ---- Mobile menu toggle
  const mobileBtn  = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  mobileBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
  });
  // Close mobile menu after clicking a link
  mobileMenu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => mobileMenu.classList.add('hidden'));
  });

  // ---- Sticky navbar - add shadow after scrolling past hero
  const navbar = document.getElementById('navbar');
  const updateNavbar = () => {
    if (window.scrollY > 20) {
      navbar.classList.add('shadow-md');
    } else {
      navbar.classList.remove('shadow-md');
    }
  };
  window.addEventListener('scroll', updateNavbar, { passive: true });
  updateNavbar();

  // ---- Booking triggers: Tour packages
  document.querySelectorAll('.book-tour-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      // The data-tour attribute stores original English label - refresh from current language dictionary
      const tourLabel = btn.getAttribute('data-tour');
      openBookingModal(tourLabel);
    });
  });

  // ---- Booking triggers: Guides (delegated because guide cards are re-rendered on language change)
  document.getElementById('guides-grid').addEventListener('click', (e) => {
    const btn = e.target.closest('.book-guide-btn');
    if (!btn || btn.disabled) return;
    const guideName = btn.getAttribute('data-guide-name');
    openBookingModal(guideName);
  });

  // ---- Modal close: X button, backdrop click, Escape key
  modalCloseBtn.addEventListener('click', closeBookingModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeBookingModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !modal.classList.contains('hidden')) closeBookingModal();
  });

  // ---- Booking form submit
  bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    // In production this would POST to /api/bookings.
    // For now: show success state, then auto-close after 2.5s.
    bookingSuccess.classList.remove('hidden');
    setTimeout(() => {
      closeBookingModal();
    }, 2500);
  });

  // ---- Date field: prevent picking past dates
  const dateInput = bookingForm.querySelector('[name="date"]');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
  }

  // ---- Footer: current year
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();
});
